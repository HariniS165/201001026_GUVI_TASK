<?php
        $email = $_POST['email'];
        $password = $_POST['password'];

        $redis = new Redis(); 
        $redis->connect('127.0.0.1', 6379);
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbName = "guvi";

        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

        if ($conn->connect_error) {
            die('Could not connect to the database.');
        }
        else {
              $sql = "SELECT * FROM register WHERE email = '$email' AND password = '$password'";
              $result = mysqli_query($conn, $sql);
              if (mysqli_num_rows($result) == 1) {
                $token = generateToken();
                $redis->setex($token, 1800, $email);
                setcookie("sessionToken", $token, time() + 1800, "/");
                echo "success";
                }
              else{
                  echo "error"; 
              }
            }
        function generateToken() {
           return bin2hex(openssl_random_pseudo_bytes(16));
        }
      
?>