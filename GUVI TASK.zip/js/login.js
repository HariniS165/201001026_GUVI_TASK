function submit(){
    event.preventDefault();
    var email = document.getElementById("email").value;
	var password = document.getElementById("password").value;

    if(isEmpty(email)|| isEmpty(password)){
        alert("No fields to be left blank");
    }
    localStorage.setItem("email", email);
    localStorage.setItem("password",password);
    $.ajax({
    url: "/GUVI TASK/php/login.php",
    type: "POST",
    dataType: 'text',
    data: {
      email: email,
      password: password
    },
    success: function(response) {
        if (response == "success") {
           alert("Login Successfully!");
           window.location.href = "/GUVI TASK/profile.html";
        } else {
           alert("Invalid email or password");
        }
      }
  });
}
function isEmpty(str) {
    return (!str || str.length === 0 );
}
function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}