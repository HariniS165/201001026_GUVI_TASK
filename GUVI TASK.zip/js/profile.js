var dateOfBirth = null;
const currentDate = new Date();
var age = null;

function calculateAge() {
  var currentDate = new Date();
  dateOfBirth = document.getElementById("dob").value;
  var dob = new Date(dateOfBirth);
  var ageInYears = currentDate.getFullYear() - dob.getFullYear();
  var ageInMonths = currentDate.getMonth() - dob.getMonth();
  var ageInDays = currentDate.getDate() - dob.getDate();
  if(ageInMonths < 0){
    age = ageInYears - 1;
  }
  else if(ageInMonths == 0 && ageInDays < 0){
    age = ageInYears - 1;
  }
  else{
    age = ageInYears;
  }
  document.getElementById("age").value = age;
}

function submit(){
	event.preventDefault();
    var emailId = localStorage.getItem("email");
    var name=document.getElementById("name").value;
    var gender=document.getElementById("gender").value;
    var contact=document.getElementById("contact").value;
    var city=document.getElementById("city").value;
    var state=document.getElementById("state").value;
    var country=document.getElementById("country").value;
    if(isEmpty(name)|| isEmpty(dateOfBirth)|| isEmpty(gender) || isEmpty(contact) || isEmpty(city) || isEmpty(state) || isEmpty(country)){
        alert("No fields to be left blank");
    }


    $.ajax({
    url: "/GUVI TASK/php/profile.php",
    type: "POST",
    dataType: 'text',
    data: {
      email:emailId,
      name:name,
      dob:dateOfBirth,
      age:age,
      gender:gender,
      contact:contact,
      city:city,
      state:state,
      country:country,
    },
    success: function(response) {
      
      alert(response);
    },
    error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
    }
  });
}

function isEmpty(str) {
    return (!str || str.length === 0 );
}